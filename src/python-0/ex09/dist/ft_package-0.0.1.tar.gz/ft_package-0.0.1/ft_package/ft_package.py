def count_in_list(lst, item):
    """def count_in_list(lst, item):"""
    return sum([1 for elem in lst if elem == item])